This directory is cloned from https://github.com/OpenZeppelin/zeppelin-solidity.git 370e6a8 commit
