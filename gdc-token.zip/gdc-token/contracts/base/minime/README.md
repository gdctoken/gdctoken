https://github.com/Giveth/minime/tree/ea04d950eea153a04c51fa510b068b9dded390cb
